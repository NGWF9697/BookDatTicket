Please follow the steps before using the program!

1)Please make sure your computer is connected to the internet or it will not be able to execute properly!

2)Please install wampserver in your computer first!

3)Run wampserver --> Start all service(Click the icon on the bottom right) --> The icon will turn green indicating that the server is connected and usable.

4)Install MySQL Query Browser. Run mySQL query browser and fill in the following:
Server Host : localhost
Port: 3306
Username: root
Default Schema: newtest
Then, Click "Ok".

4)In MySQL, File --> Open Script... --> select newtest.sql --> execute.

5)Run the program!
					